<?php
/*
** ===================
** Fastkart Ecommerce Footer
** Post type : Footer;
** version: 1.0;
** Authour : Steeltheme;
** ===================
*/
namespace Fastkartaddons\Plugins;
if (! defined('ABSPATH' )){
	die('-1');
}
class Footer{
   
	public function __construct() {
		add_action('init', array($this, 'footer_custom_post_type'));  
		add_action('init', array($this, 'Footer_custom_taxonomies')); 
 
	}
	public function footer_custom_post_type() {
		register_post_type( 'footer',
		array(
			'labels' => array(
				'name' => esc_html_x('Footers', 'Post Type General Name', 'Fastkart-addons') ,
				'singular_name' => esc_html_x('Footers', 'Post Type General Name', 'Fastkart-addons') , 
				'add_new' =>  esc_html__('Add New', 'Fastkart-addons'),
				'add_new_item' =>   esc_html__('Add New Footer', 'Fastkart-addons'),
				'edit' => esc_html__('Edit', 'Fastkart-addons'),
				'edit_item' =>   esc_html__('Edit Footer', 'Fastkart-addons'),
				'new_item' =>   esc_html__('New Footer', 'Fastkart-addons'),
				'view' =>  esc_html__('View', 'Fastkart-addons'),
				'view_item' =>    esc_html__('View Footer', 'Fastkart-addons'),
				'search_items' =>   esc_html__('Search Footer', 'Fastkart-addons'),
				'not_found' =>   esc_html__('No Footer found', 'Fastkart-addons'),
				'not_found_in_trash' =>  esc_html__('No Footer found in Trash', 'Fastkart-addons'),
				'parent' =>  esc_html__('Parent Footer', 'Fastkart-addons')
			),
		
			'public' => true,
			'show_in_rest' => true,
			'menu_position' => 15,
			'supports' =>
			array( 'title', 
			'thumbnail' , 'editor' , 'page-attributes' ),
			'taxonomies' => array( '' ),
			'show_in_menu'        => 'Fastkart-panel',
			'show_in_nav_menus'   => false,
			'menu_position'       => 5,
			'menu_icon'           => 'dashicons-tagcloud',
			'has_archive' => false,
			'capability_type'    => 'post',
			'hierarchical'          => true,
		)
		 
		);
	}
	public function Footer_custom_taxonomies() {

		//add new taxonomy hierarchical
		$labels = array(
			'name' =>   esc_html__('Footer Categories', 'Fastkart-addons'),
			'singular_name' =>  esc_html__('Category', 'Fastkart-addons'),
			'search_items' =>  esc_html__('Search Category', 'Fastkart-addons'),
			'all_items' =>  esc_html__('All Category', 'Fastkart-addons'),
			'parent_item' =>  esc_html__('Parent Category', 'Fastkart-addons'),
			'parent_item_colon' =>   esc_html__('Parent Category:', 'Fastkart-addons'),
			'edit_item' =>   esc_html__('Edit Category', 'Fastkart-addons'),
			'update_item' =>   esc_html__('Update Category', 'Fastkart-addons'),
			'add_new_item' =>  esc_html__('Add New Footer Category', 'Fastkart-addons'),
			'new_item_name' =>   esc_html__('New Category Name', 'Fastkart-addons'),
			'menu_name' => esc_html__('Categories', 'Fastkart-addons')
		);
		$args = array(
			'hierarchical' => true,
			'labels' => $labels,
			'show_ui' => true,
			'show_admin_column' => true,
			'query_var' => true,
			'public'             => true,
			'publicly_queryable' => true,
			'show_in_rest' => true,
			'rewrite' => array( 'slug' => 'footer_category' )
		);
		register_taxonomy('footer_category', array('footer'), $args);
		//add new taxonomy NOT hierarchical
	}
}

?>