<?php

namespace  Fastkartaddons\Core\Widgets\Footer;

if (!defined('ABSPATH')) {
    exit;
} // If this file is called directly, abort.

class About_contact_v1 extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'Fastkart-foo-widget-about-contact-v1';
    }

    public function get_title()
    {
        return __('About & Contact V1', 'Fastkart-addons');
    }

    public function get_icon()
    {
        return 'icon-letter-n';
    }

    public function get_categories()
    {
        return ['104'];
    }

    protected function register_controls(){
 
        // style one start
        $this->start_controls_section('widget_about_contact_v1_settings',
        [ 
            'label' => __('Widget  Content', 'Fastkart-addons'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
        );
     
      

        $this->add_control(
            'widget_title',
            [
               'label' => __('Widget Title', 'Fastkart-addons'),
               'type' => \Elementor\Controls_Manager::TEXT,
               'default' => __('About Company', 'Fastkart-addons'),
               'placeholder' => __('Type your text here', 'Fastkart-addons'),   
            ]
        );

       

        $this->add_control(
            'description_enable',
            [
                'label' => __('Description show / hide', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );


        $this->add_control(
            'description',
            [
              'label' => __('Decription', 'Fastkart-addons'),
              'type' => \Elementor\Controls_Manager::TEXTAREA,
              'default' => __('Start Your Daily Shopping with <span class="text-brand">Fastkart Mart</span>', 'Fastkart-addons'),
              'placeholder' => __('Type your text here', 'Fastkart-addons'),
              'condition' => [
                'description_enable' => 'yes'
                ],
            ]
        );


        $this->add_control(
            'address_enable',
            [
                'label' => __('Address show / hide', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
          'address_title',
          [
             'label' => __('Address Title', 'Fastkart-addons'),
             'type' => \Elementor\Controls_Manager::TEXT,
             'default' => __('Address', 'Fastkart-addons'),
             'placeholder' => __('Type your text here', 'Fastkart-addons'),   
             'condition' => [
                'address_enable' => 'yes'
            ], 
          ]
        );
        $this->add_control(
            'address',
            [
               'label' => __('Address', 'Fastkart-addons'),
               'type' => \Elementor\Controls_Manager::TEXTAREA,
               'default' => __('5171 W Campbell Ave undefined Kent, Utah 53127 United States', 'Fastkart-addons'),
               'placeholder' => __('Type your text here', 'Fastkart-addons'),   
               'condition' => [
                  'address_enable' => 'yes'
              ], 
            ]
        );


        $this->add_control(
            'phone_enable',
            [
                'label' => __('Phone show / hide', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
          'phone_title',
          [
             'label' => __('Phone Title', 'Fastkart-addons'),
             'type' => \Elementor\Controls_Manager::TEXT,
             'default' => __('Call Us', 'Fastkart-addons'),
             'placeholder' => __('Type your text here', 'Fastkart-addons'),   
             'condition' => [
                'phone_enable' => 'yes'
            ], 
          ]
        );
        $this->add_control(
            'phone',
            [
               'label' => __('Phone', 'Fastkart-addons'),
               'type' => \Elementor\Controls_Manager::TEXTAREA,
               'default' => __('(+91)-540-025-124553', 'Fastkart-addons'),
               'placeholder' => __('Type your text here', 'Fastkart-addons'),   
               'condition' => [
                  'phone_enable' => 'yes'
              ], 
            ]
        );


        $this->add_control(
            'email_enable',
            [
                'label' => __('Mail show / hide', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
          'email_title',
          [
             'label' => __('Mail Title', 'Fastkart-addons'),
             'type' => \Elementor\Controls_Manager::TEXT,
             'default' => __('Email', 'Fastkart-addons'),
             'placeholder' => __('Type your text here', 'Fastkart-addons'),   
             'condition' => [
                'email_enable' => 'yes'
            ], 
          ]
        );
        $this->add_control(
            'email',
            [
               'label' => __('Mail', 'Fastkart-addons'),
               'type' => \Elementor\Controls_Manager::TEXTAREA,
               'default' => __('sale@Fastkart.com', 'Fastkart-addons'),
               'placeholder' => __('Type your text here', 'Fastkart-addons'),   
               'condition' => [
                  'email_enable' => 'yes'
              ], 
            ]
        );


        $this->add_control(
            'timing_enable',
            [
                'label' => __('Timing show / hide', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
          'timing_title',
          [
             'label' => __('Timing Title', 'Fastkart-addons'),
             'type' => \Elementor\Controls_Manager::TEXT,
             'default' => __('Hours', 'Fastkart-addons'),
             'placeholder' => __('Type your text here', 'Fastkart-addons'),   
             'condition' => [
                'timing_enable' => 'yes'
            ], 
          ]
        );
        $this->add_control(
            'timing',
            [
               'label' => __('Timing', 'Fastkart-addons'),
               'type' => \Elementor\Controls_Manager::TEXTAREA,
               'default' => __('10:00 - 18:00, Mon - Sat', 'Fastkart-addons'),
               'placeholder' => __('Type your text here', 'Fastkart-addons'),   
               'condition' => [
                  'timing_enable' => 'yes'
              ], 
            ]
        );
         
         
        
        $this->add_control(
            'transition_enable',
            [
                'label' => __('Transition Enable', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'wow_animation',
            [
                'label' => esc_html__( 'Transition Timing', 'Fastkart-addons' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0'  => esc_html__( '0', 'Fastkart-addons' ),
                    '.1s' => esc_html__( '.1s', 'Fastkart-addons' ),
                    '.2s' => esc_html__( '.2s', 'Fastkart-addons' ),
                    '.3s' => esc_html__( '.3s', 'Fastkart-addons' ),
                    '.4s' => esc_html__( '.4s', 'Fastkart-addons' ),
                    '.5s' => esc_html__( '.5s', 'Fastkart-addons' ),
                    '.6s' => esc_html__( '.6s', 'Fastkart-addons' ),
                    '.7s' => esc_html__( '.7s', 'Fastkart-addons' ),
                    '.8s' => esc_html__( '.8s', 'Fastkart-addons' ),
                    '.9s' => esc_html__( '.9s', 'Fastkart-addons' ),
                    '1s' => esc_html__( '1s', 'Fastkart-addons' ),
                    '1.1s' => esc_html__( '1.1s', 'Fastkart-addons' ),
                    '1.2s' => esc_html__( '1.2s', 'Fastkart-addons' ),
                    '1.3s' => esc_html__( '1.3s', 'Fastkart-addons' ),
                    '1.4s' => esc_html__( '1.4s', 'Fastkart-addons' ),
                    '1.5s' => esc_html__( '1.5s', 'Fastkart-addons' ),
                    '1.6s' => esc_html__( '1.6s', 'Fastkart-addons' ),
                    '1.7s' => esc_html__( '1.7s', 'Fastkart-addons' ),
                    '1.8s' => esc_html__( '1.8s', 'Fastkart-addons' ),
                    '1.9s' => esc_html__( '1.9s', 'Fastkart-addons' ),
                    '2s' => esc_html__( '2s', 'Fastkart-addons' ),
                ],
                'condition' => [
                    'transition_enable' => 'yes'
                ], 
            ]
        );  

    $this->end_controls_section();

    $this->start_controls_section('aboutcompany_css',
    [ 
        'label' => __('About Company Css', 'Fastkart-addons'),
        'tab' =>\Elementor\Controls_Manager::TAB_STYLE,
    ]
    );

    
  
    $this->add_control(
        'title_color',
         [
            'label' => __('Title Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .widget-about .foo_wid_title ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );
    
  
    $this->add_control(
        'description_color',
         [
            'label' => __('Description Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .widget-about .font-lg.mb-30.text-heading , {{WRAPPER}} .widget-about .font-lg.mb-30.text-heading a ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );

    $this->add_control(
        'icon_color',
         [
            'label' => __('Icon Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .widget-about .contact-infor i ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );

    $this->add_control(
        'content_title_color',
         [
            'label' => __('Content Title Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .widget-about strong  ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );

    $this->add_control(
        'content_color',
         [
            'label' => __('Content Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .widget-about .contact-infor a , {{WRAPPER}} .widget-about .contact-infor span  ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );

 

    $this->end_controls_section();

    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
       
    ?>
  


    <div class="widget-about footer_widgets  font-md <?php if($settings['transition_enable'] == 'yes'): ?> wow animate__animated animate__fadeInUp" data-wow-delay="<?php echo esc_attr($settings['wow_animation']); ?><?php endif; ?>">
        <?php if(!empty($settings['widget_title'])): ?>
            <div class="foo_wid_title">
                <?php echo wp_kses($settings['widget_title'] , $allowed_tags); ?>
            </div>
        <?php endif; ?>

    <div class="widget_content_box">


        <?php if($settings['description_enable'] == 'yes'): // description ?>
            <p class="font-lg  mb-30 text-heading"><?php echo wp_kses($settings['description'] , $allowed_tags); ?></p>
        <?php endif; // description ?>
       
        <?php if($settings['address_enable'] == 'yes'): // Address ?>
            <div class="contact-infor">
            <?php if(!empty($settings['address_title'])): ?>
                <i class="fi-rs-marker"></i> 
                <strong><?php echo wp_kses($settings['address_title'] , $allowed_tags); ?></strong> 
            <?php endif; ?>
            <?php if(!empty($settings['address'])): ?>
                <span><?php echo wp_kses($settings['address'] , $allowed_tags); ?></span>
            <?php endif; ?>
        </div>
        <?php endif; // Address ?>
        <?php if($settings['phone_enable'] == 'yes'): // phone ?>
            <div class="contact-infor">
            <?php if(!empty($settings['phone_title'])): ?>
                <i class="fi-rs-headphones"></i>
                <strong><?php echo wp_kses($settings['phone_title'] , $allowed_tags); ?></strong>
            <?php endif; ?>
            <?php if(!empty($settings['phone'])): ?>
                <a href="tel:<?php echo esc_attr($settings['phone']); ?>"><?php echo esc_attr($settings['phone']); ?></a>
            <?php endif; ?>
        </div>
        <?php endif; // phone ?>
        <?php if($settings['email_enable'] == 'yes'): // mail ?>
            <div class="contact-infor">
            <?php if(!empty($settings['email_title'])): ?>
                <i class="fi-rs-envelope"></i>
                <strong><?php echo wp_kses($settings['email_title'] , $allowed_tags); ?></strong>
                <?php endif; ?>
            <?php if(!empty($settings['email'])): ?>
                <a href="mailto:<?php echo esc_attr($settings['email']); ?>"><?php echo esc_attr($settings['email']); ?></a>
            <?php endif; ?>
        </div>
        <?php endif; // mail ?>
        <?php if($settings['timing_enable'] == 'yes'): // timing ?>
            <div class="contact-infor">
            <?php if(!empty($settings['timing_title'])): ?>
                <i class="fi-rs-time-oclock"></i>
                <strong><?php echo wp_kses($settings['timing_title'] , $allowed_tags); ?></strong>
            <?php endif; ?>
            <?php if(!empty($settings['timing'])): ?>
                <span><?php echo wp_kses($settings['timing'] , $allowed_tags); ?></span>
            <?php endif; ?>
        </div>
        <?php endif; // timing ?>
        </div>
    </div>

   

    <?php
    }
}

 

