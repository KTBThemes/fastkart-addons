<?php

namespace  Fastkartaddons\Core\Widgets\Content;

if (!defined('ABSPATH')) {
    exit;
} // If this file is called directly, abort.

class Simple_image_box_v1 extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'Fastkart-simple-image-box-v1';
    }

    public function get_title()
    {
        return __('Image V1' , 'Fastkart-addons');
    }

    public function get_icon()
    {
        return 'icon-letter-n';
    }

    public function get_categories()
    {
        return ['102'];
    }

    

    protected function register_controls() {

		$this->start_controls_section(
			'simple_image_type',
			[
				'label' => esc_html__( 'Image Content', 'Fastkart-addons' ),
			]
        );


        $this->add_control(
            'image_type',
            [
              'label' => __('Image Type', 'Fastkart-addons'),
              'type' => \Elementor\Controls_Manager::SELECT,
              'options' => [
                'image' => __( 'Image', 'Fastkart-addons' ),
                'carousel' => __( 'Image Carousel', 'Fastkart-addons' ),
                ],
              'default' => 'image' ,
            ]
        );

        $this->add_control(
            'image_carousel_type',
            [
              'label' => __('Carousel Items', 'Fastkart-addons'),
              'type' => \Elementor\Controls_Manager::SELECT,
              'options' => [
                'carausel-3-columns' => __( 'Three Items', 'Fastkart-addons' ),
                'carausel-4-columns' => __( 'Four Items', 'Fastkart-addons' ),
                ],
              'default' => 'carausel-3-columns' , 
              'condition' => [
                'image_type' => 'carousel',
               ],
            ]
        );

        $this->add_control(
            'category_caro_items',
            [
            'label' => __('Carousel Items to Display', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'options' => [
                '10' => __('10 Items', 'Fastkart-addons'),
                '9' => __('9 Items', 'Fastkart-addons'),
                '8' => __('8 Items', 'Fastkart-addons'),
                '7' => __('7 Items', 'Fastkart-addons'),
                '6' => __('6 Items', 'Fastkart-addons'),
                '5' => __('5 Items', 'Fastkart-addons'),
                '4' => __('4 Items', 'Fastkart-addons'),
                '3' => __('3 Items', 'Fastkart-addons'),
                '2' => __('2 Items', 'Fastkart-addons'),
                '1' => __('1 Items', 'Fastkart-addons'),
            ],
            'default' => '10' , 
            ]
        );


        $this->add_control(
            'image_fit_enable',
            [
              'label' => __( 'Image Fit Enable', 'Fastkart-addons' ),
              'type' => \Elementor\Controls_Manager::SWITCHER,
              'label_on' => __( 'Show', 'Fastkart-addons' ),
              'label_off' => __( 'Hide', 'Fastkart-addons' ),
              'return_value' => 'yes',
              'default' => 'no',
            ]
        );

        $this->add_control(
			'img_height',
			[
				'label' => __( 'Image Height', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 10000,
				'step' => 1,
				'default' => 400,
                'selectors' => [
					'{{WRAPPER}} .simple_image_boxes , {{WRAPPER}} .simple_image_boxes img ' => 'height: {{VALUE}}px',
				],
			]
		);
        $this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],

				'selectors' => [
					'{{WRAPPER}} .simple_image_boxes , {{WRAPPER}} .simple_image_boxes img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				],
			]
		);


        $this->end_controls_section();


        $this->start_controls_section(
			'simple_image_content',
			[
				'label' => esc_html__( 'Image Content', 'Fastkart-addons' ),
                'condition' => [
                    'image_type' => 'image',
                ],
			]
        );
     

        $this->add_control(
			'image',
			[
				'label' => __( 'Image', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
              
			]
        );


        
        $this->add_control(
            'transition_enable',
            [
                'label' => __('Transition Enable', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'wow_animation',
            [
                'label' => esc_html__( 'Transition Timing', 'Fastkart-addons' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0'  => esc_html__( '0', 'Fastkart-addons' ),
                    '.1s' => esc_html__( '.1s', 'Fastkart-addons' ),
                    '.2s' => esc_html__( '.2s', 'Fastkart-addons' ),
                    '.3s' => esc_html__( '.3s', 'Fastkart-addons' ),
                    '.4s' => esc_html__( '.4s', 'Fastkart-addons' ),
                    '.5s' => esc_html__( '.5s', 'Fastkart-addons' ),
                    '.6s' => esc_html__( '.6s', 'Fastkart-addons' ),
                    '.7s' => esc_html__( '.7s', 'Fastkart-addons' ),
                    '.8s' => esc_html__( '.8s', 'Fastkart-addons' ),
                    '.9s' => esc_html__( '.9s', 'Fastkart-addons' ),
                    '1s' => esc_html__( '1s', 'Fastkart-addons' ),
                    '1.1s' => esc_html__( '1.1s', 'Fastkart-addons' ),
                    '1.2s' => esc_html__( '1.2s', 'Fastkart-addons' ),
                    '1.3s' => esc_html__( '1.3s', 'Fastkart-addons' ),
                    '1.4s' => esc_html__( '1.4s', 'Fastkart-addons' ),
                    '1.5s' => esc_html__( '1.5s', 'Fastkart-addons' ),
                    '1.6s' => esc_html__( '1.6s', 'Fastkart-addons' ),
                    '1.7s' => esc_html__( '1.7s', 'Fastkart-addons' ),
                    '1.8s' => esc_html__( '1.8s', 'Fastkart-addons' ),
                    '1.9s' => esc_html__( '1.9s', 'Fastkart-addons' ),
                    '2s' => esc_html__( '2s', 'Fastkart-addons' ),
                ],
                'condition' => [
                    'transition_enable' => 'yes'
                ], 
            ]
        );  
        
        $this->end_controls_section();

        $this->start_controls_section(
			'simple_image_content_carousel',
			[
				'label' => esc_html__( 'Image Content', 'Fastkart-addons' ),
                'condition' => [
                    'image_type' => 'carousel',
                ],
			]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'r_image',
			[
				'label' => __( 'Image', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
              
			]
        );

     

        $this->add_control(
            'image_repeater',
            [
                'label' => __('Image Repeater', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'r_image' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                    [
                        'r_image' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                    [
                        'r_image' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
  
                ],
                'title_field' => __( 'Image', 'Fastkart-addons' ),
    
            ]
          );
        $this->end_controls_section();

        $this->start_controls_section('owl_nav_style',
    [ 
        'label' => __('Custom Css', 'Fastkart-addons'),
        'tab' =>\Elementor\Controls_Manager::TAB_STYLE,
        'condition' => [
            'image_type' => 'carousel',
        ],
    ]
    );
 

    $this->add_control(
        'nav_style_options',
        [
        'label' => __('Nav Move Position', 'Fastkart-addons'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'options' => [
            'none_nav' => __( 'Select Nav Position', 'Fastkart-addons' ),
            'position_one' => __( 'Position One', 'Fastkart-addons' ),
            'position_two' => __( 'Position Two', 'Fastkart-addons' ),
            'position_three' => __( 'Position Three', 'Fastkart-addons' ),
            'position_four' => __( 'Position Four', 'Fastkart-addons' ),
        ],
        'default' => 'none_nav' , 
        ]
    );
 
    $this->add_control(
        'nav_display',
        [
        'label' => __('Naigation Enable / Disabel', 'Fastkart-addons'),
        'type' => \Elementor\Controls_Manager::SELECT,
        'options' => [
            'true' => __( 'Block', 'Fastkart-addons' ),
            'false' => __( 'none', 'Fastkart-addons' ),
        ],
        'default' => 'true' , 
       
        ]
    );

 

    $this->end_controls_section();
	}
    protected function render() {
		$settings = $this->get_settings_for_display();
    $allowed_tags = wp_kses_allowed_html('post');
?>
<?php if($settings['image_type'] == 'carousel'): ?>

 
    <div class="<?php echo esc_attr($settings['image_carousel_type']); ?>-cover <?php if($settings['image_fit_enable'] == 'yes'): ?> image_fit <?php endif; ?> position-relative image_custom_caro <?php echo esc_attr($settings['nav_style_options']); ?>">
         
        <div class="theme_carousel owl-theme owl-carousel" data-options='{"loop": false, "margin": 20, "autoheight":true, "lazyload":true, "nav": <?php echo esc_attr($settings['nav_display']); ?>, "dots": false, "autoplay": false, "autoplayTimeout": 6000, "smartSpeed": 300, "responsive":{ "0" :{ "items": "1" }, "600" :{ "items" : "2" }, "768" :{ "items" : "2" } , "992":{ "items" : "3" }, "1200":{ "items" : "<?php echo esc_attr($settings['category_caro_items']); ?>" }}}'>
        <?php foreach($settings['image_repeater'] as  $key => $image_repeater): ?>
        <img src="<?php echo esc_url($image_repeater['r_image']['url']); ?>" alt="image" />
        <?php endforeach; ?>
    </div>    
</div>
 
<?php else: ?>
<?php if(!empty($settings['image']['url'])): ?>
<div class="simple_image_boxes <?php if($settings['image_fit_enable'] == 'yes'): ?> image_fit <?php endif; ?> 
    <?php if($settings['transition_enable']  == 'yes'): ?>wow animate__animated animate__fadeInUp"
    data-wow-delay="<?php echo esc_html($settings['wow_animation']); ?><?php endif; ?>">
    <img src="<?php echo esc_url($settings['image']['url']); ?>" alt="image" />
</div>
<?php endif; ?>
  
<?php endif; ?>

<?php 
	}
}
 