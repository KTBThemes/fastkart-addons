<?php

namespace  Fastkartaddons\Core\Widgets\Content;

if (!defined('ABSPATH')) {
    exit;
} // If this file is called directly, abort.

class Fun_facts_v1 extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'Fastkart-fun-facts-v1';
    }

    public function get_title()
    {
        return __('Funfacts V1', 'Fastkart-addons');
    }

    public function get_icon()
    {
        return 'icon-letter-n';
    }

    public function get_categories()
    {
        return ['102'];
    }

    protected function register_controls(){
 
        // style one start
        $this->start_controls_section('funfacts_content_v1_settings',
        [ 
            'label' => __('Funfacts Content', 'Fastkart-addons'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
        );
       
        $this->add_control(
            'funfacts_number',
            [
              'label' => __('Count', 'Fastkart-addons'),
              'type' => \Elementor\Controls_Manager::TEXT,
              'default' => __('545', 'Fastkart-addons'),
              'placeholder' => __('Type your text here', 'Fastkart-addons'),
            ]
        );

        $this->add_control(
            'funfacts_symbol',
            [
              'label' => __('Symbol', 'Fastkart-addons'),
              'type' => \Elementor\Controls_Manager::TEXT,
              'default' => __('+', 'Fastkart-addons'),
              'placeholder' => __('Type your Symbols here', 'Fastkart-addons'),
            ]
        );


        $this->add_control(
          'title',
          [
             'label' => __('Title', 'Fastkart-addons'),
             'type' => \Elementor\Controls_Manager::TEXTAREA,
             'default' => __('  Stay home & get your daily <br />  needs from our shop', 'Fastkart-addons'),
             'placeholder' => __('Type your text here', 'Fastkart-addons'),    
          ]
        );
        
        

       
        $this->add_control(
            'transition_enable',
            [
                'label' => __('Transition Enable', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'wow_animation',
            [
                'label' => esc_html__( 'Transition Timing', 'Fastkart-addons' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0'  => esc_html__( '0', 'Fastkart-addons' ),
                    '.1s' => esc_html__( '.1s', 'Fastkart-addons' ),
                    '.2s' => esc_html__( '.2s', 'Fastkart-addons' ),
                    '.3s' => esc_html__( '.3s', 'Fastkart-addons' ),
                    '.4s' => esc_html__( '.4s', 'Fastkart-addons' ),
                    '.5s' => esc_html__( '.5s', 'Fastkart-addons' ),
                    '.6s' => esc_html__( '.6s', 'Fastkart-addons' ),
                    '.7s' => esc_html__( '.7s', 'Fastkart-addons' ),
                    '.8s' => esc_html__( '.8s', 'Fastkart-addons' ),
                    '.9s' => esc_html__( '.9s', 'Fastkart-addons' ),
                    '1s' => esc_html__( '1s', 'Fastkart-addons' ),
                    '1.1s' => esc_html__( '1.1s', 'Fastkart-addons' ),
                    '1.2s' => esc_html__( '1.2s', 'Fastkart-addons' ),
                    '1.3s' => esc_html__( '1.3s', 'Fastkart-addons' ),
                    '1.4s' => esc_html__( '1.4s', 'Fastkart-addons' ),
                    '1.5s' => esc_html__( '1.5s', 'Fastkart-addons' ),
                    '1.6s' => esc_html__( '1.6s', 'Fastkart-addons' ),
                    '1.7s' => esc_html__( '1.7s', 'Fastkart-addons' ),
                    '1.8s' => esc_html__( '1.8s', 'Fastkart-addons' ),
                    '1.9s' => esc_html__( '1.9s', 'Fastkart-addons' ),
                    '2s' => esc_html__( '2s', 'Fastkart-addons' ),
                ],
                'condition' => [
                    'transition_enable' => 'yes'
                ], 
            ]
        );  

    $this->end_controls_section();

    $this->start_controls_section('funfact_css',
    [ 
        'label' => __('Fun Fact Css', 'Fastkart-addons'),
        'tab' =>\Elementor\Controls_Manager::TAB_STYLE,
    ]
    );

  
    $this->add_control(
        'count_color',
         [
            'label' => __('Count Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .about-count.text-center .heading-1 span ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );

     
    $this->add_control(
        'symbol_color',
         [
            'label' => __('Symbols Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .about-count.text-center .heading-1 ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );
     
    $this->add_control(
        'heading_color',
         [
            'label' => __('Heading Color', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .about-count.text-center h4 ' => 'color: {{VALUE}}!important;',
            ],
         ]
    );
     
    $this->end_controls_section();

    }
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
     ?>
        
 

    <div class="about-count text-center <?php if($settings['transition_enable'] == 'yes'): ?> wow animate__animated animate__fadeInUp" data-wow-delay="<?php echo esc_attr($settings['wow_animation']); ?><?php endif; ?>">
            <h3 class="heading-1"><span class="counters"><?php echo esc_attr($settings['funfacts_number']) ?></span><?php echo esc_attr($settings['funfacts_symbol']) ?></h3>
            <?php if(!empty($settings['title'])): ?>
                <div class="ftitle"><?php echo wp_kses($settings['title'] , $allowed_tags); ?></div>
            <?php endif; ?>
    </div>

   



    <?php
    }
}

 

