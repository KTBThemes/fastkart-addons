<?php

namespace  Fastkartaddons\Core\Widgets\Content;

if (!defined('ABSPATH')) {
    exit;
} // If this file is called directly, abort.

class Theme_btn_v1 extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'Fastkart-themebtns-v1';
    }

    public function get_title()
    {
        return __('Theme Buttons V1' , 'Fastkart-addons');
    }

    public function get_icon()
    {
        return 'icon-letter-n';
    }

    public function get_categories()
    {
        return ['102'];
    }

    protected function register_controls(){   
        $this->start_controls_section(
            'theme_btn_content',
            [
                'label' => __('theme Button Content', 'Fastkart-addons')
            ]
        );

        $this->add_control(
            'theme_btn_styles',
            [
                'label' => __('theme Button Styles', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'style_one' => __( 'Style One', 'Fastkart-addons' ),
                    'style_two' => __( 'Style Two', 'Fastkart-addons' ),
                
				],
                'default' => 'style_one' ,
            ]
        );

      
        $this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'Fastkart-addons' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
                'default' =>  esc_html__( 'Contact us' , 'Fastkart-addons'),
		]);

        $this->add_control(
            'button_link',
        [
            'label' => __('Theme Link', 'Fastkart-addons'),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'Fastkart-addons'),
            'show_external' => true,
            'default' => [
                'url' => '#',
                'is_external' => true,
                'nofollow' => true,
            ],
        ]
        );  

        $this->add_control(
            'transition_enable',
            [
                'label' => __('Transition Enable', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'Fastkart-addons'),
                'label_off' => __('No', 'Fastkart-addons'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'wow_animation',
            [
                'label' => esc_html__( 'Transition Timing', 'Fastkart-addons' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0'  => esc_html__( '0', 'Fastkart-addons' ),
                    '.1s' => esc_html__( '.1s', 'Fastkart-addons' ),
                    '.2s' => esc_html__( '.2s', 'Fastkart-addons' ),
                    '.3s' => esc_html__( '.3s', 'Fastkart-addons' ),
                    '.4s' => esc_html__( '.4s', 'Fastkart-addons' ),
                    '.5s' => esc_html__( '.5s', 'Fastkart-addons' ),
                    '.6s' => esc_html__( '.6s', 'Fastkart-addons' ),
                    '.7s' => esc_html__( '.7s', 'Fastkart-addons' ),
                    '.8s' => esc_html__( '.8s', 'Fastkart-addons' ),
                    '.9s' => esc_html__( '.9s', 'Fastkart-addons' ),
                    '1s' => esc_html__( '1s', 'Fastkart-addons' ),
                    '1.1s' => esc_html__( '1.1s', 'Fastkart-addons' ),
                    '1.2s' => esc_html__( '1.2s', 'Fastkart-addons' ),
                    '1.3s' => esc_html__( '1.3s', 'Fastkart-addons' ),
                    '1.4s' => esc_html__( '1.4s', 'Fastkart-addons' ),
                    '1.5s' => esc_html__( '1.5s', 'Fastkart-addons' ),
                    '1.6s' => esc_html__( '1.6s', 'Fastkart-addons' ),
                    '1.7s' => esc_html__( '1.7s', 'Fastkart-addons' ),
                    '1.8s' => esc_html__( '1.8s', 'Fastkart-addons' ),
                    '1.9s' => esc_html__( '1.9s', 'Fastkart-addons' ),
                    '2s' => esc_html__( '2s', 'Fastkart-addons' ),
                ],
                'condition' => [
                    'transition_enable' => 'yes'
                ], 
            ]
        );  
        
        
     
        $this->end_controls_section();

        $this->start_controls_section('theme_btn_css',
        [ 
            'label' => __('Theme Button Css', 'Fastkart-addons'),
            'tab' =>\Elementor\Controls_Manager::TAB_STYLE,
        ]
        );
        $this->add_control(
            'button_color',
             [
                'label' => __('Button Color', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme_btn_all a  ' => 'color: {{VALUE}}!important;',
                ],
             ]
        );
        
        $this->add_control(
            'button_bg_color',
             [
                'label' => __('Button Background Color', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme_btn_all a  ' => 'background: {{VALUE}}!important;',
                ],
             ]
        );
        
        $this->add_control(
			'button_padding',
			[
				'label' => esc_html__( 'Button Padding', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme_btn_all a ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				],
			]
		);

        $this->add_control(
			'button_border_radiuse',
			[
				'label' => esc_html__( 'Border Radius', 'Fastkart-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .theme_btn_all a ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important;',
				],
			]
		);

        $this->add_responsive_control(
            'btn_alignments',
            [
                'label' => __('Button alignments', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                  'left' => [
                    'title' => __( 'Text Left', 'Fastkart-addons' ),
                    'icon' => 'fa fa-align-left',
                  ],
                  'center' => [
                    'title' => __( 'Text Center', 'Fastkart-addons' ),
                    'icon' => 'fa fa-align-center',
                  ],
                  'right' => [
                    'title' => __( 'Text Right', 'Fastkart-addons' ),
                    'icon' => 'fa fa-align-right',
                  ],
                ],
                'default' => 'text-left',
                'toggle' => true,
                'selectors' => [
                  '{{WRAPPER}} .theme_btn_all' => 'text-align: {{VALUE}}!important;',
                ],
            ]
        );
  


        $this->add_control(
            'button_hover_color',
             [
                'label' => __('Button Hover Color', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme_btn_all a:hover  ' => 'color: {{VALUE}}!important;',
                ],
             ]
        );
        
        $this->add_control(
            'button_hovre_bg_color',
             [
                'label' => __('Button Hover Background Color', 'Fastkart-addons'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .theme_btn_all a:hover  ' => 'background: {{VALUE}}!important;',
                ],
             ]
        );
 
        $this->end_controls_section();
        
 
      
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
        $target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
        $nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; ?>
      
        <?php if($settings['theme_btn_styles'] == 'style_two'): ?>
        <div class="theme_btn_all  <?php if($settings['transition_enable'] == 'yes'): ?> wow animate__animated animate__fadeInUp" data-wow-delay="<?php echo esc_attr($settings['wow_animation']); ?>"<?php endif; ?>>
        <a class="show-all" href="<?php echo esc_url($settings['button_link']['url']);?>"  <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>
            <?php echo esc_html($settings['button_text']);?>
            <i class="fi-rs-angle-right"></i>
        </a>
        </div>
        <?php else: ?>
            <div class="theme_btn_all <?php if($settings['transition_enable'] == 'yes'): ?> wow animate__animated animate__fadeInUp" data-wow-delay="<?php echo esc_attr($settings['wow_animation']); ?><?php endif; ?>">
            <a href="<?php echo esc_url($settings['button_link']['url']);?>"  <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?> class="btn text-center">
              <?php echo esc_html($settings['button_text']);?>
            </a>
        </div>
        <?php endif; ?>
<?php
    }
}

 