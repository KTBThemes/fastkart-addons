<?php 
/*
** ============================== 
**   Fastkart Ecommerce Theme Panel
** ==============================
*/ 
 
function Fastkart_add_theme_admin_menu(){
    add_menu_page( 
        __( 'Fastkart Theme', 'Fastkart-addons' ),
        'Fastkart',
        'manage_options',
        'Fastkart-panel',
        null ,
        plugins_url( '/Fastkart-addons/assets/imgs/Fastkart-dash-icon.png'),
        3.1
    ); 
    add_submenu_page(
        'Fastkart-panel',
        esc_html__( 'About Fastkart Theme', 'Fastkart-addons' ),
        esc_html__( 'About Fastkart ', 'Fastkart-addons' ),
        'manage_options',
        'Fastkart-panel',
        'Fastkart_panel_output',
        0
    );
}
add_action( 'admin_menu', 'Fastkart_add_theme_admin_menu' );
 
/**
 * Display a custom menu page
 */
function Fastkart_panel_output(){
    ?>
    <div class="Fastkart_admin_boxed clearfix" id="Fastkart_admin_boxed_id">
    <div class="Fastkart_panel_top welcome-panel">
        <div class="bg_n_image">
            <img src="<?php echo esc_url(Fastkart_ADDONS_URL . '/assets/imgs/Fastkart-admin-bg.jpg'); ?>" alt="Fastkart-bg" />
        </div>
        <div class="about_Fastkart_panel">
            <h1><?php echo esc_html_e('Fastkart' , 'Fastkart-addons'); ?> <span><?php echo esc_html('V 1.5' , 'Fastkart-addons'); ?> </span></h1>
            <p><?php echo esc_html_e('WooCommerce Marketplace WordPress Theme' , 'Fastkart-addons'); ?></p>
     </div>
</div>
<div class="theme_Fastkart_register">
    <h2><?php echo esc_html_e('Fastkart theme registered' , 'Fastkart-addons'); ?></h2>
    <p><?php echo esc_html_e('Envato allows 1 license for 1 project located on 1 domain. It means that 1 
    purchase key can be used only for 1 site. Each additional site will require an additional purchase key.', 'Fastkart-addons'); ?></p>

        
</div>
    <div class="d-flex clearfix">
        <div class="box_Fastkart">
            <a href="https://themepanthers.com/wp/Fastkart/documentation/change-logs" target="_blank">
                <div class="card">
                    <h6><?php echo esc_html_e('Change Logs' , 'Fastkart-addons'); ?></h6>
                </div>
            </a>
        </div>
        <div class="box_Fastkart">
            <a href="https://themepanthers.com/wp/Fastkart/documentation/" target="_blank">
                <div class="card">
                    <h6><?php echo esc_html_e('Documentation' , 'Fastkart-addons'); ?></h6>
                </div>
            </a>
        </div>
        <div class="box_Fastkart">
            <a href="https://themepanthers.com/wp/Fastkart/documentation/video-tutorials/" target="_blank">
                <div class="card">
                    <h6><?php echo esc_html_e('Video Tutorials' , 'Fastkart-addons'); ?></h6>
                </div>
            </a>
        </div>
        <div class="box_Fastkart">
            <a href="https://zootemplate.ticksy.com/submit/#100019994" target="_blank">
                <div class="card">
                    <h6><?php echo esc_html_e('Support' , 'Fastkart-addons'); ?></h6>
                </div>
            </a>
        </div>
</div>
    
 
    <div class="theme_authour_panel  welcome-panel">
    <div class="bg_n_image">
            <img src="<?php echo esc_url(Fastkart_ADDONS_URL . '/assets/imgs/zootemplate.jpg'); ?>" alt="Fastkart-bg" />
        </div>
        <div class="about_zootemplate">
            <h6><?php echo esc_html_e('Theme Authour' , 'Fastkart-addons'); ?> </h6>
            <h1><?php echo esc_html_e('zootemplate' , 'Fastkart-addons'); ?> </h1>
            <p><?php echo esc_html_e('We build all our templates with care and love. all our templates are 100% responsive' , 'Fastkart-addons'); ?></p>
            <a class="btn" href="https://themeforest.net/user/zootemplate" target="_blank">
               <?php echo esc_html_e('View Our Profile' , 'Fastkart-addons'); ?>   
            </a>
    </div>  
 </div>
</div>
    <?php
}
add_action( 'admin_notices', 'Fastkart_admin_notice__success' );
function Fastkart_admin_notice__success() {
    ?>
 <div class="Fastkart-leadin-banner notice notice-warning is-dismissible"> <p><strong class="red"> <?php echo esc_html_e('Fastkart Notice -> Soon We Are going to add Purchase Code Validator', 'Fastkart-addons'); ?></strong></p></div>
 <div class="Fastkart-leadin-banner notice notice-warning is-dismissible"> <p><strong class="red"> <?php echo esc_html_e('Fastkart Notice -> Make Sure If you Have backup before updating the theme and plugins.', 'Fastkart-addons'); ?></strong></p></div>
    <?php
}
