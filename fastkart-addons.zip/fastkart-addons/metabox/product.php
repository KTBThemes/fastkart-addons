<?php
return array(
	'title'      => 'Fastkart  Setting',
	'id'         => 'Fastkart_post_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array('product'),
	'sections'   => array(

		
        require Fastkart_ADDONS_DIR . '/metabox/options/general.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/pageheader.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/product-single-style.php',
		
        require Fastkart_ADDONS_DIR . '/metabox/options/product.php',
        require Fastkart_ADDONS_DIR . '/metabox/options/product-hover.php',
        require Fastkart_ADDONS_DIR . '/metabox/options/product-deals.php',
        require Fastkart_ADDONS_DIR . '/metabox/options/product-data.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/product-message.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/product-video.php',
	),
);