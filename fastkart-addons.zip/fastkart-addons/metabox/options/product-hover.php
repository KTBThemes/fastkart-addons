<?php

return array(
	'id'     => 'Fastkart_product_img_settings',
	'title'  => esc_html__( "Product Hover Image", "Fastkart-addons" ),
	'fields' => array(

        array(
            'title' => esc_html__('Hover Product Image', 'Fastkart-addons') ,
            'id' => 'hover_product_image',
            'type' => 'image_advanced',
            'type' => 'media',
            'url'      => true,
           
        ) ,
    
	),
);

