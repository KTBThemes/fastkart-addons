<?php

return array(
	'id'     => 'Fastkart_product_video_settings',
	'title'  => esc_html__( "Product Video", "Fastkart-addons" ),
	'fields' => array(

        array(
            'title' => esc_html__('Product Video Enable', 'Fastkart-addons') ,
            'id' => 'product_video_enable',
            'type' => 'switch',
            'default'  => false,
        ),

        array(
			'id'    => 'product_video_styles',
			'type'  => 'select',
			'title' => esc_html__( 'Product Video Styles', 'Fastkart-addons' ),
			'options' => array(
				'style_one' => esc_html('Style One' , 'Fastkart-addons'),
                'style_two' => esc_html('Style Two' , 'Fastkart-addons'),
			),
			'default'  => 'style_one',
			'required' => array( 'product_video_enable', '=', true ),
		),

        array(
            'title' => esc_html__('Video Text', 'Fastkart-addons') ,
            'id' => 'porduct_video_texts',
            'type' => 'text',
            'default' => esc_html('<i class="fa fa-play"></i>Play Video' ,'Fastkart-addons' ),
            'required' => array( 'product_video_styles', '=', 'style_one' ),
        ),  

        array(
			'id'    => 'product_video_types',
			'type'  => 'select',
			'title' => esc_html__( 'Product Video Type', 'Fastkart-addons' ),
			'options' => array(
				'iframe' => esc_html('Iframe(Embed )' , 'Fastkart-addons'),
                'video' => esc_html('Video Mp4' , 'Fastkart-addons'),
			),
			'default'  => 'iframe',
			'required' => array( 'product_video_styles', '=', 'style_two' ),
		),

      
        array(
            'title'		=> esc_html__('Video Link','Fastkart-addons'),
            'id'		=> 'product_video_link',
            'type'		=> 'textarea',
            'required' => array( 'product_video_enable', '=', true ),
            'default' => esc_html('https://youtu.be/embed/SjpAiw7CNzk' ,'Fastkart-addons' ),
            'desc' =>  esc_html('Enter the Video link here' ,'Fastkart-addons' ),
        ),
    
	),
);

