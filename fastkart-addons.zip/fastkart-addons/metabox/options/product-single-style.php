<?php

return array(
	'id'     => 'Fastkart_product_singlestyle_settings',
	'title'  => esc_html__( "Product Single Style", "Fastkart-addons" ),
	'fields' => array(

        array(
            'title' => esc_html__('Product Single Style Enable', 'Fastkart-addons') ,
            'id' => 'product_signle_style_enable',
            'type' => 'switch',
            'default'  => false,
        ),

        array(
			'id'    => 'product_single_styles',
			'type'  => 'select',
			'title' => esc_html__( 'Product Single Styles', 'Fastkart-addons' ),
			'options' => array(
				'style_one' => esc_html('Style One ( Default )' , 'Fastkart-addons'),
                'style_two' => esc_html('Style Two' , 'Fastkart-addons'),
                'style_three' => esc_html('Style Three' , 'Fastkart-addons'),
                'style_four' => esc_html('Style Four' , 'Fastkart-addons'),
			),
			'default'  => 'style_one',
			'required' => array( 'product_signle_style_enable', '=', true ),
		),
    
	),
);

