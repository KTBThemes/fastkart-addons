<?php

return array(
	'id'     => 'Fastkart_pageheader_settings',
	'title'  => esc_html__( "Page Header Settings", "Fastkart-addons" ),
	'fields' => array(
		array(
			'id'       => 'page_header_enable_disable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Disable  / Enable', 'Fastkart-addons' ),
			'default'  => false,
			'desc' =>  esc_html__( 'Here  (Switch Off) is Enable and (Switch On) is Disable', 'Fastkart-addons' ),
		),

		array(
			'id'       => 'page_header_style_enable_disable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Style Enable / Disable', 'Fastkart-addons' ),
			'default'  => false,
			'desc' =>  esc_html__( 'Here  (Switch On) is Enable and (Switch Off) is Disable', 'Fastkart-addons' ),
			'required' => array( 'page_header_enable_disable', '=', false ),
		),

		array(
            'id'    => 'custom_pageheader_style',
            'type'  => 'select',
            'title' => esc_html__( 'Choose Header Position', 'Fastkart-addons' ),
            'options'  => array(
                'style_one' => esc_html('Page Header Style One' , 'Fastkart-addons'),
                'style_two' => esc_html('Page Header Style Two' , 'Fastkart-addons'),
                'style_three' => esc_html('Page Header Style Three (Only Breadcrumb)' , 'Fastkart-addons'),
            ),
            'default'  => 'style_one',
			'required' => array( 'page_header_style_enable_disable', '=', true ),
        ),

	
		array(
			'id'       => 'page_header_title',
			'type'     => 'textarea',
			'title'    =>  esc_html__('Page Header Title', 'Fastkart-addons') ,
			'desc'     => esc_html__( 'Enter the title to show in Page Header section', 'Fastkart-addons' ),
			'required' => array( 'page_header_enable_disable', '=', false ),
		),
	 
		 
		array(
			'id'       => 'page_header_bg_image_showss',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Image Enable / Disable', 'Fastkart-addons' ),
			'default'  => false,
			'desc' =>  esc_html__( 'Here  (Switch Off) is Disable and (Switch On) is Enable', 'Fastkart-addons' ),
			'required' => array( 'page_header_enable_disable', '=', false),
		),

		array(
			'id'       => 'page_header_bgimage',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Page Header Background Image', 'Fastkart-addons' ),
			'desc'     => esc_html__( 'Insert Background Image for Page Header', 'Fastkart-addons' ),
			'required' => array( 'page_header_bg_image_showss', '=', true),
		),
	 
 
	),
);