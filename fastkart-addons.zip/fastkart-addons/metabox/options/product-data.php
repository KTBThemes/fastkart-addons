<?php

return array(
	'id'     => 'Fastkart_product_data_settings',
	'title'  => esc_html__( "Product Data", "Fastkart-addons" ),
	'fields' => array(


        array(
            'title' => esc_html__('Product Data Enable', 'Fastkart-addons') ,
            'id' => 'product_data_enable',
            'type' => 'switch',
            'default'  => true,
        ),
       
        array(
            'title'		=> esc_html__('Product Type','Fastkart-addons'),
            'id'		=> 'product_type',
            'type'		=> 'text',
            'required' => array( 'product_data_enable', '=', true ),
        ),
        
        array(
            'title'		=> esc_html__('Product MFG','Fastkart-addons'),
            'id'		=> 'product_mfg',
            'type'		=> 'text',
            'required' => array( 'product_data_enable', '=', true ),
        ),
        
        array(
            'title'		=> esc_html__('Product LIFE','Fastkart-addons'),
            'id'		=> 'product_life',
            'type'		=> 'text',
            'required' => array( 'product_data_enable', '=', true ),
        ),

	),
);

