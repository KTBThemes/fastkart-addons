<?php

return array(
	'id'     => 'Fastkart_product_deals_settings',
	'title'  => esc_html__( "Product Deals", "Fastkart-addons" ),
	'fields' => array(
        
        array(
            'title' => esc_html__('Product Deals Image', 'Fastkart-addons') ,
            'id' => 'product_deals_image',
            'type' => 'media',
            'url'      => true,
        ) ,

        array(
            'title'		=> esc_html__('Product Deals Text','Fastkart-addons'),
            'id'		=> 'product_deals_text',
            'type'		=> 'text',
            'placeholder' => __('Remains until the end of the offer' , 'Fastkart-addons'),
        ),
        
        array(
            'title' => esc_html__('Products Deals Date', 'Fastkart-addons') ,
            'id' => 'product_deals_date',
            'type' => 'text',
            'desc' => 'Example ( Enter Deals Date End Time Like this 2025/02/25)',
        ),

    
	),
);

