<?php
return array(
	'title'      => 'Fastkart Setting',
	'id'         => 'Fastkart_post_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array('post'),
	'sections'   => array(
		require Fastkart_ADDONS_DIR . '/metabox/options/post.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/pageheader.php',
		require Fastkart_ADDONS_DIR . '/metabox/options/general.php',
	),
);