<?php
if ( ! function_exists( "Fastkart_add_metaboxes" ) ) {
	function Fastkart_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'product.php',
			'post.php'
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( Fastkart_ADDONS_DIR . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/Fastkart_theme_mod/boxes", "Fastkart_add_metaboxes" );
}

